﻿// App.h: 标准系统包含文件的包含文件
// 或项目特定的包含文件。

#pragma once

#include <iostream>

#include<glad/glad.h>
#include<GLFW/glfw3.h>